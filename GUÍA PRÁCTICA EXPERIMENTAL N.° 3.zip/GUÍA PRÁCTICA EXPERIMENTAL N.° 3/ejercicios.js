class OperacionesMatematicas {

    fibonacci(objeto) {
        const n = objeto.numero;
        if (n <= 0) return [];
        if (n === 1) return [0];
        
        const serie = [0, 1];
        for (let i = 2; i < n; i++) {
            serie[i] = serie[i - 1] + serie[i - 2];
        }
        return serie;
    }
    
    divisores(objeto) {
        const num = objeto.numero;
        const divisores = [];
        for (let i = 1; i <= num; i++) {
            if (num % i === 0) {
                divisores.push(i);
            }
        }
        return divisores;
    }
    
    sumaDivisores(objeto) {
        const divisores = this.divisores(objeto);
        let suma = 0;
        for (let i = 0; i < divisores.length; i++) {
            suma += divisores[i];
        }
        return suma;
    }
    
    esPerfecto(objeto) {
        const num = objeto.numero;
        let suma = 0;
        for (let i = 1; i < num; i++) {
            if (num % i === 0) {
                suma += i;
            }
        }
        return suma === num;
    }
    
    esPrimo(objeto) {
        const num = objeto.numero;
        if (num <= 1) return false;
        for (let i = 2; i < num; i++) {
            if (num % i === 0) {
                return false;
            }
        }
        return true;
    }
    
    invertirNumero(objeto) {
        let num = objeto.numero;
        let invertido = 0;
        while (num > 0) {
            invertido = invertido * 10 + (num % 10);
            num = Math.floor(num / 10);
        }
        return invertido;
    }
    
    contarDigitos(objeto) {
        let num = objeto.numero;
        let contador = 0;
        if (num === 0) return 1;
        while (num > 0) {
            contador++;
            num = Math.floor(num / 10);
        }
        return contador;
    }
    
    factorial(objeto) {
        const num = objeto.numero;
        let resultado = 1;
        for (let i = 2; i <= num; i++) {
            resultado *= i;
        }
        return resultado;
    }
    
    sumasSucesivas(objeto) {
        const num = objeto.numero;
        const veces = objeto.veces;
        let resultado = 0;
        for (let i = 0; i < veces; i++) {
            resultado += num;
        }
        return resultado;
    }
    
    restasSucesivas(objeto) {
        let num = objeto.numero;
        const num2 = objeto.numero2;
        while (num >= num2) {
            num -= num2;
        }
        return num;
    }
    
    fibonacciVarios(coleccion) {
        const resultados = [];
        for (let i = 0; i < coleccion.length; i++) {
            resultados.push(this.fibonacci(coleccion[i]));
        }
        return resultados;
    }
    
    divisoresVarios(coleccion) {
        const resultados = [];
        for (let i = 0; i < coleccion.length; i++) {
            resultados.push(this.divisores(coleccion[i]));
        }
        return resultados;
    }
    
    sumaDivisoresVarios(coleccion) {
        const resultados = [];
        for (let i = 0; i < coleccion.length; i++) {
            resultados.push(this.sumaDivisores(coleccion[i]));
        }
        return resultados;
    }
    
    detectarPerfectos(coleccion) {
        const perfectos = [];
        for (let i = 0; i < coleccion.length; i++) {
            if (this.esPerfecto(coleccion[i])) {
                perfectos.push(coleccion[i].numero);
            }
        }
        return perfectos;
    }
    
    detectarPrimos(coleccion) {
        const primos = [];
        for (let i = 0; i < coleccion.length; i++) {
            if (this.esPrimo(coleccion[i])) {
                primos.push(coleccion[i].numero);
            }
        }
        return primos;
    }
    
    invertirNumerosVarios(coleccion) {
        const resultados = [];
        for (let i = 0; i < coleccion.length; i++) {
            resultados.push(this.invertirNumero(coleccion[i]));
        }
        return resultados;
    }
    
    contarDigitosVarios(coleccion) {
        const resultados = [];
        for (let i = 0; i < coleccion.length; i++) {
            resultados.push(this.contarDigitos(coleccion[i]));
        }
        return resultados;
    }
    
    factorialVarios(coleccion) {
        const resultados = [];
        for (let i = 0; i < coleccion.length; i++) {
            resultados.push(this.factorial(coleccion[i]));
        }
        return resultados;
    }
    
    sumasSucesivasVarios(coleccion) {
        const resultados = [];
        for (let i = 0; i < coleccion.length; i++) {
            resultados.push(this.sumasSucesivas(coleccion[i]));
        }
        return resultados;
    }
    
    restasSucesivasVarios(coleccion) {
        const resultados = [];
        for (let i = 0; i < coleccion.length; i++) {
            resultados.push(this.restasSucesivas(coleccion[i]));
        }
        return resultados;
    }
}

const operaciones = new OperacionesMatematicas();

debugger;

console.log(" BLOQUE 1: EJERCICIOS CON OBJETOS INDIVIDUALES ");

console.log("1. Serie de Fibonacci de 8 términos:");
console.log("Resultado:", operaciones.fibonacci({numero: 8}));
console.log("---");

console.log("2. Divisores del número 12:");
console.log("Resultado:", operaciones.divisores({numero: 12}));
console.log("---");

console.log("3. Suma de divisores del número 12:");
console.log("Resultado:", operaciones.sumaDivisores({numero: 12}));
console.log("---");

console.log("4. Verificar si el número 6 es perfecto:");
console.log("Resultado:", operaciones.esPerfecto({numero: 6}));
console.log("---");

console.log("5. Verificar si el número 11 es primo:");
console.log("Resultado:", operaciones.esPrimo({numero: 11}));
console.log("---");

console.log("6. Invertir los dígitos del número 1234:");
console.log("Resultado:", operaciones.invertirNumero({numero: 1234}));
console.log("---");

console.log("7. Contar dígitos del número 9876:");
console.log("Resultado:", operaciones.contarDigitos({numero: 9876}));
console.log("---");

console.log("8. Factorial del número 5:");
console.log("Resultado:", operaciones.factorial({numero: 5}));
console.log("---");

console.log("9. Sumas sucesivas: 3 sumado 4 veces:");
console.log("Resultado:", operaciones.sumasSucesivas({numero: 3, veces: 4}));
console.log("---");

console.log("10. Restas sucesivas: 15 restado por 4 repetidamente:");
console.log("Resultado:", operaciones.restasSucesivas({numero: 15, numero2: 4}));
console.log("---");

console.log(" BLOQUE 2: COLECCIÓN DE OBJETOS ");

const coleccion1 = [{numero: 5}, {numero: 8}, {numero: 10}];
console.log("1. Serie de Fibonacci para varios objetos:");
console.log("Entrada:", coleccion1);
console.log("Resultado:", operaciones.fibonacciVarios(coleccion1));
console.log("---");

const coleccion2 = [{numero: 6}, {numero: 10}, {numero: 15}];
console.log("2. Divisores de varios objetos:");
console.log("Entrada:", coleccion2);
console.log("Resultado:", operaciones.divisoresVarios(coleccion2));
console.log("---");

const coleccion3 = [{numero: 6}, {numero: 12}, {numero: 28}];
console.log("3. Suma de divisores de varios objetos:");
console.log("Entrada:", coleccion3);
console.log("Resultado:", operaciones.sumaDivisoresVarios(coleccion3));
console.log("---");

const coleccion4 = [{numero: 6}, {numero: 10}, {numero: 28}, {numero: 30}];
console.log("4. Detectar números perfectos:");
console.log("Entrada:", coleccion4);
console.log("Resultado:", operaciones.detectarPerfectos(coleccion4));
console.log("---");

const coleccion5 = [{numero: 5}, {numero: 6}, {numero: 7}, {numero: 8}, {numero: 11}];
console.log("5. Números primos en una lista:");
console.log("Entrada:", coleccion5);
console.log("Resultado:", operaciones.detectarPrimos(coleccion5));
console.log("---");

const coleccion6 = [{numero: 123}, {numero: 456}, {numero: 780}];
console.log("6. Invertir los números de varios objetos:");
console.log("Entrada:", coleccion6);
console.log("Resultado:", operaciones.invertirNumerosVarios(coleccion6));
console.log("---");

const coleccion7 = [{numero: 45}, {numero: 678}, {numero: 12345}];
console.log("7. Contar dígitos de varios objetos:");
console.log("Entrada:", coleccion7);
console.log("Resultado:", operaciones.contarDigitosVarios(coleccion7));
console.log("---");

const coleccion8 = [{numero: 3}, {numero: 4}, {numero: 5}];
console.log("8. Factorial de varios objetos:");
console.log("Entrada:", coleccion8);
console.log("Resultado:", operaciones.factorialVarios(coleccion8));
console.log("---");

const coleccion9 = [
    {numero: 2, veces: 4},
    {numero: 3, veces: 4},
    {numero: 4, veces: 4}
];
console.log("9. Sumas sucesivas en varios objetos:");
console.log("Entrada:", coleccion9);
console.log("Resultado:", operaciones.sumasSucesivasVarios(coleccion9));
console.log("---");

const coleccion10 = [
    {numero: 15, numero2: 4},
    {numero: 22, numero2: 4},
    {numero: 30, numero2: 4}
];
console.log("10. Restas sucesivas en varios objetos:");
console.log("Entrada:", coleccion10);
console.log("Resultado:", operaciones.restasSucesivasVarios(coleccion10));
console.log("---");

